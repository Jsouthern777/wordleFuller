import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        newGame();

    }
    public static List readWords() {
        try {
            Scanner in = new Scanner(new File("words.txt"));
            List<String> words = new LinkedList<>();
            while(in.hasNextLine()){
                words.add(in.nextLine().toUpperCase());
            }
            return words;
        } catch (Exception e){
            System.out.println("An error occurred while reading the file: " + e.getMessage());
        }
        return null;
    }
    public static void newGame(){
        List<String> wordList = readWords();
        Random r = new Random();
        String answer = wordList.get(r.nextInt(wordList.size()));
        Game g = new Game(answer);
    }
}
